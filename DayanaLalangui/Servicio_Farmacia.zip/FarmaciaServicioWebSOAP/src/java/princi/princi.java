/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package princi;

import java.util.ArrayList;
import modelo.Distribuidor;
import modelo.Farmacia;
import modelo.Medicamento;
import modelo.Pedido;

/**
 *
 * @author LENOVO
 */
public class princi {
    ArrayList <Farmacia>listaFarmacias = new ArrayList<>();
    ArrayList <Distribuidor>listaDistribuidores = new ArrayList<>();
    ArrayList <Medicamento>listaMedicamentos = new ArrayList<>();
    ArrayList <Pedido>listaPedidos= new ArrayList<>();
    public void crearDatos() {
    // Crear instancias de Medicamento
    Medicamento medicamento1 = new Medicamento("Paracetamol", "Analgésico");
    Medicamento medicamento2 = new Medicamento("Ibuprofeno", "Analgésico");
    Medicamento medicamento3 = new Medicamento("Amoxicilina", "Antibiótico");

    // Crear instancias de Distribuidor
    Distribuidor distribuidor1 = new Distribuidor("COFARMA");
    Distribuidor distribuidor2 = new Distribuidor("EMPSEPHAR");
    Distribuidor distribuidor3 = new Distribuidor("CEMEFAR");

    // Crear instancias de Farmacia
    Farmacia farmaciaPrincipal = new Farmacia("PRINCIPAL", "Octavio Chacón Moscoso");
    Farmacia farmaciaSecundaria = new Farmacia("SECUNDARIA", "Calle AV de la Independencia");

    // Crear instancias de Pedido
    Pedido pedido1 = new Pedido(medicamento1, 20, distribuidor1, "PRINCIPAL");
    Pedido pedido2 = new Pedido(medicamento2, 30, distribuidor2, "SECUNDARIA");
    Pedido pedido3 = new Pedido(medicamento3, 15, distribuidor3, "PRINCIPAL");

    // Agregar los objetos creados a las listas correspondientes
    listaMedicamentos.add(medicamento1);
    listaMedicamentos.add(medicamento2);
    listaMedicamentos.add(medicamento3);

    listaDistribuidores.add(distribuidor1);
    listaDistribuidores.add(distribuidor2);
    listaDistribuidores.add(distribuidor3);

    listaFarmacias.add(farmaciaPrincipal);
    listaFarmacias.add(farmaciaSecundaria);

    listaPedidos.add(pedido1);
    listaPedidos.add(pedido2);
    listaPedidos.add(pedido3);
}

     
    /**
     * This is a sample web service operation
     */
}
