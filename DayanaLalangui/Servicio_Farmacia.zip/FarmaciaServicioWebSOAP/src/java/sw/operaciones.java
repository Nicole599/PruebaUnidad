/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sw;

import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import modelo.Distribuidor;
import modelo.Farmacia;
import modelo.Medicamento;
import modelo.Pedido;
import princi.princi;

/**
 *
 * @author LENOVO
 */
@WebService(serviceName = "operaciones")
public class operaciones {
    ArrayList <Farmacia>listaFarmacias = new ArrayList<>();
    ArrayList <Distribuidor>listaDistribuidores = new ArrayList<>();
    ArrayList <Medicamento>listaMedicamentos = new ArrayList<>();
    ArrayList <Pedido>listaPedidos= new ArrayList<>();

    
     public static void main(String[] args){
      princi p =new princi();
    }
     
     
     // Dentro del método crearDatos() en la clase Conversion
public void crearDatos() {
    // Crear instancias de Medicamento
    Medicamento medicamento1 = new Medicamento("Paracetamol", "Analgésico");
    Medicamento medicamento2 = new Medicamento("Ibuprofeno", "Analgésico");
    Medicamento medicamento3 = new Medicamento("Amoxicilina", "Antibiótico");

    // Crear instancias de Distribuidor
    Distribuidor distribuidor1 = new Distribuidor("COFARMA");
    Distribuidor distribuidor2 = new Distribuidor("EMPSEPHAR");
    Distribuidor distribuidor3 = new Distribuidor("CEMEFAR");

    // Crear instancias de Farmacia
    Farmacia farmaciaPrincipal = new Farmacia("PRINCIPAL", "Octavio Chacón Moscoso");
    Farmacia farmaciaSecundaria = new Farmacia("SECUNDARIA", "Calle AV de la Independencia");

    // Crear instancias de Pedido
    Pedido pedido1 = new Pedido(medicamento1, 20, distribuidor1, "PRINCIPAL");
    Pedido pedido2 = new Pedido(medicamento2, 30, distribuidor2, "SECUNDARIA");
    Pedido pedido3 = new Pedido(medicamento3, 15, distribuidor3, "PRINCIPAL");

    // Agregar los objetos creados a las listas correspondientes
    listaMedicamentos.add(medicamento1);
    listaMedicamentos.add(medicamento2);
    listaMedicamentos.add(medicamento3);

    listaDistribuidores.add(distribuidor1);
    listaDistribuidores.add(distribuidor2);
    listaDistribuidores.add(distribuidor3);

    listaFarmacias.add(farmaciaPrincipal);
    listaFarmacias.add(farmaciaSecundaria);

    listaPedidos.add(pedido1);
    listaPedidos.add(pedido2);
    listaPedidos.add(pedido3);
}

     
    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
    
    
    @WebMethod(operationName = "crearProducto")
    public void crearProducto(@WebParam(name = "nombre") String nombre, 
                          @WebParam(name = "tipo") String tipo) {
    // Crear una nueva instancia de Medicamento con los datos proporcionados
    Medicamento nuevoMedicamento = new Medicamento(nombre, tipo);
    
    // Agregar el nuevo medicamento a la lista de medicamentos
    listaMedicamentos.add(nuevoMedicamento);
    
    System.out.println("¡Medicamento creado exitosamente!");
}

    @WebMethod(operationName = "hacerPedido")
public String hacerPedido(@WebParam(name = "nombreUsuario") String nombreUsuario,
                          @WebParam(name = "fechaNacimiento") int fechaNacimiento) {
    // Obtener la primera letra del nombre del usuario
    char primeraLetraNombre = Character.toLowerCase(nombreUsuario.charAt(0));
    
    // Obtener el medicamento según las especificaciones adicionales
    String nombreMedicamento;
    if (primeraLetraNombre == 'd') {
        nombreMedicamento = "Diclofenaco"; 
    } else {
        nombreMedicamento = "MedicamentoInventado"; 
    }
    
    // Utilizar el día de nacimiento del usuario como cantidad del pedido
    int cantidad = fechaNacimiento;
    
    // Establecer el distribuidor según el mes de nacimiento del usuario
    String distribuidor;
    int mesNacimiento = (fechaNacimiento / 100) % 100;
    if (mesNacimiento >= 1 && mesNacimiento <= 4) {
        distribuidor = "COFARMA";
    } else if (mesNacimiento >= 5 && mesNacimiento <= 8) {
        distribuidor = "EMPSEPHAR";
    } else {
        distribuidor = "CEMEFAR";
    }
    
    
    String sucursalFarmacia;
    char ultimoCaracterNombre = Character.toLowerCase(nombreUsuario.charAt(nombreUsuario.length() - 1));
    if (ultimoCaracterNombre == 'a' || ultimoCaracterNombre == 'e' || ultimoCaracterNombre == 'i' || ultimoCaracterNombre == 'o' || ultimoCaracterNombre == 'u') {
        sucursalFarmacia = "PRINCIPAL";
    } else {
        sucursalFarmacia = "SECUNDARIA";
    }
    
    
    
    String resumenPedido = "Pedido al distribuidor " + distribuidor + ": " +
                           cantidad + " unidades del " + nombreMedicamento +
                           ". Para la farmacia situada en " + sucursalFarmacia +
                           ". Pedido Enviado Correctamente";

    // Devolver el resumen del pedido
    return resumenPedido;
}
   
}
