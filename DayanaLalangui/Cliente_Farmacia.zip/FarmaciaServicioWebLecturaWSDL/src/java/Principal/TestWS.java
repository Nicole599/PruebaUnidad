/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;

import sw.Operaciones;
import sw.Operaciones_Service;

/**
 *
 * @author LENOVO
 */
public class TestWS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Crear una instancia del servicio web
        Operaciones_Service servicio = new Operaciones_Service();
        // Obtener el puerto del servicio
        Operaciones cliente = servicio.getOperacionesPort();
        // Llamar al método crearProducto
        cliente.crearProducto("NombreProducto", "TipoProducto");
        
        // Llamar al método hacerPedido
        String resultadoPedido = cliente.hacerPedido("UsuarioPrueba", 10);
        System.out.println("Respuesta de hacerPedido: " + resultadoPedido);
    }
    
}
